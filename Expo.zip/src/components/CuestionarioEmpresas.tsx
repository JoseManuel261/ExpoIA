"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import PoliticaModal from "@/components/PoliticaModal";

type Pregunta = { id: string; numero: string; texto: string; tipo?: "text" | "number" | "select" | "multi" | "scale" | "matrix"; opciones?: string[]; filas?: string[]; filtro?: (respuestas: Record<string, string | string[]>) => boolean };
const siNo = ["Sí", "No", "No sabe"];
const municipios = ["Neiva", "Acevedo", "Agrado", "Aipe", "Algeciras", "Altamira", "Baraya", "Campoalegre", "Colombia", "Elías", "Garzón", "Gigante", "Guadalupe", "Hobo", "Íquira", "Isnos", "La Argentina", "La Plata", "Nátaga", "Oporapa", "Paicol", "Palermo", "Palestina", "Pital", "Pitalito", "Rivera", "Saladoblanco", "San Agustín", "Santa María", "Suaza", "Tarqui", "Tesalia", "Tello", "Teruel", "Timaná", "Villavieja", "Yaguará"];
const sectores = ["Agricultura, ganadería, caza, silvicultura y pesca", "Minas y canteras", "Industrias manufactureras", "Electricidad, gas y agua", "Construcción", "Comercio y reparación de vehículos", "Transporte y almacenamiento", "Alojamiento y servicios de comida", "Información y comunicaciones", "Actividades financieras y de seguros", "Actividades profesionales, científicas y técnicas", "Servicios administrativos y de apoyo", "Administración pública", "Educación", "Salud y asistencia social", "Arte, entretenimiento y recreación", "Otras actividades de servicios", "Otro"];
const procesos = ["Dirección y planeación", "Administración y gestión documental", "Contabilidad y finanzas", "Gestión del talento humano", "Análisis de información y decisiones", "Mercadeo, publicidad y redes sociales", "Ventas y gestión comercial", "Servicio y atención al cliente", "Diseño de productos y servicios", "Producción o prestación del servicio", "Compras y proveedores", "Inventarios, transporte y logística", "Control de calidad", "Seguridad y salud en el trabajo", "Gestión ambiental"];
const beneficios = ["Ahorro de tiempo", "Reducción de costos", "Incremento de ventas", "Mayor productividad", "Mejor servicio al cliente", "Mejor calidad", "Mejor toma de decisiones", "Mayor presencia digital", "Nuevos productos o servicios", "Automatización", "Mayor innovación"];
const limitaciones = ["Falta de conocimiento", "No saber dónde aplicarla", "Falta de capacitación", "Costo de herramientas", "Falta de recursos", "Equipos o conectividad insuficientes", "Información desorganizada", "Falta de personal especializado", "Resistencia de trabajadores", "Falta de tiempo", "Privacidad y seguridad", "Información incorrecta", "Incertidumbre jurídica o ética", "Otra"];

const preguntas: Pregunta[] = [
  { id: "empresa", numero: "1", texto: "Nombre o razón social de la empresa o establecimiento", tipo: "text" },
  { id: "identificacion", numero: "2", texto: "NIT sin dígito de verificación, o número de matrícula mercantil", tipo: "text" },
  { id: "municipio", numero: "4", texto: "Municipio en el que se encuentra ubicada la sede principal", tipo: "select", opciones: municipios },
  { id: "zona", numero: "5", texto: "¿La sede está ubicada en cabecera municipal o zona rural?", tipo: "select", opciones: ["Cabecera municipal", "Centro poblado o zona rural"] },
  { id: "presencia", numero: "6", texto: "¿En qué otros municipios tiene presencia la empresa?", tipo: "multi", opciones: [...municipios, "Otros departamentos de Colombia", "Presencia internacional", "No tiene presencia en otros municipios"] },
  { id: "sector", numero: "7", texto: "Sector económico principal", tipo: "select", opciones: sectores },
  { id: "otroSector", numero: "7.1", texto: "Otro sector económico, ¿cuál?", tipo: "text", filtro: r => r.sector === "Otro" },
  { id: "actividad", numero: "8", texto: "Actividad, producto o servicio principal", tipo: "text" },
  { id: "tamano", numero: "9", texto: "¿Cuántas personas trabajan actualmente en la empresa?", tipo: "select", opciones: ["Micro: hasta 10", "Pequeña: 11 a 50", "Mediana: 51 a 200", "Grande: más de 200"] },
  { id: "antiguedad", numero: "10", texto: "¿En qué rango inició operaciones la empresa?", tipo: "select", opciones: ["Menos de 1 año", "Entre 1 y 3 años", "Entre 4 y 7 años", "Entre 8 y 15 años", "Más de 15 años"] },
  { id: "genero", numero: "12", texto: "¿La persona propietaria o gerente es hombre o mujer?", tipo: "select", opciones: ["Hombre", "Mujer", "Otro", "Prefiere no responder"] },
  { id: "ventas", numero: "13", texto: "¿La empresa vende fuera del departamento o exporta?", tipo: "multi", opciones: ["Solo en el Huila", "También en otros departamentos", "Exporta"] },
  { id: "cargo", numero: "14", texto: "Cargo de la persona que diligencia la encuesta", tipo: "select", opciones: ["Propietario o gerente", "Administrador", "Responsable de tecnología", "Responsable de mercadeo o ventas", "Responsable de producción", "Trabajador o colaborador", "Otro"] },
  { id: "otroCargo", numero: "14.1", texto: "Otro cargo, ¿cuál?", tipo: "text", filtro: r => r.cargo === "Otro" },
  { id: "recursos", numero: "16", texto: "Indique si la empresa utiliza actualmente cada recurso", tipo: "matrix", filas: ["Computador", "Teléfono inteligente empresarial", "Internet permanente", "Página web", "Redes sociales empresariales", "Comercio electrónico", "Software contable", "Facturación electrónica", "CRM", "Almacenamiento en la nube", "Software de inventarios", "Sistemas de análisis de datos"], opciones: siNo },
  { id: "organizacionInfo", numero: "17", texto: "¿Cómo califica la organización y disponibilidad de la información?", tipo: "select", opciones: ["Principalmente física", "Archivos digitales dispersos", "Digitalizada y parcialmente organizada", "Organizada en sistemas", "Integrada para análisis y decisiones"] },
  { id: "responsableTecnologia", numero: "18", texto: "¿Cuenta con una persona o proveedor responsable de tecnología?", tipo: "select", opciones: ["Personal interno", "Proveedor externo", "Una persona con otras funciones", "No cuenta", "No sabe"] },
  { id: "presupuestoTecnologia", numero: "19", texto: "Presupuesto anual aproximado para tecnología, en millones de pesos", tipo: "select", opciones: ["No tiene definido", "Menos de 2", "De 2 a menos de 10", "De 10 a menos de 30", "30 o más", "Prefiere no responder", "No sabe"] },
  { id: "conocimientoIA", numero: "20", texto: "Antes de esta encuesta, ¿qué tanto conocía la IA aplicada a empresas?", tipo: "select", opciones: ["No había escuchado", "Había escuchado, sin saber aplicarla", "Conocía algunas herramientas", "Conocía aplicaciones empresariales", "Podría implementar proyectos"] },
  { id: "usaIA", numero: "21", texto: "¿En la empresa se utiliza actualmente alguna herramienta de IA?", tipo: "select", opciones: ["Sí", "No", "No sabe"] },
  { id: "descripcionUso", numero: "22", texto: "¿Cuál descripción se acerca más al uso de IA?", tipo: "select", opciones: ["Probada sin uso regular", "Uso regular en tareas puntuales", "Uso en procesos completos", "Soluciones integradas a la operación"], filtro: r => r.usaIA === "Sí" },
  { id: "origenUso", numero: "23", texto: "¿Cómo se originó ese uso?", tipo: "select", opciones: ["Iniciativa de trabajadores sin decisión empresarial", "Iniciativa conocida y permitida", "Decisión sin lineamientos formales", "Decisión con lineamientos definidos"], filtro: r => r.usaIA === "Sí" },
  { id: "tiempoIA", numero: "24", texto: "¿Desde hace cuánto utiliza herramientas de IA?", tipo: "select", opciones: ["Menos de 3 meses", "3 a 6 meses", "7 a 12 meses", "1 a 2 años", "Más de 2 años"], filtro: r => r.usaIA === "Sí" },
  { id: "productosIA", numero: "25", texto: "¿Cuáles productos utiliza la empresa?", tipo: "multi", opciones: ["ChatGPT", "Gemini", "Microsoft Copilot", "Claude", "Perplexity u otro buscador", "Código abierto", "Otro", "No identifica la herramienta"], filtro: r => r.usaIA === "Sí" },
  { id: "otroProductoIA", numero: "25.1", texto: "Otro producto de inteligencia artificial, ¿cuál?", tipo: "text", filtro: r => r.usaIA === "Sí" && Array.isArray(r.productosIA) && r.productosIA.includes("Otro") },
  { id: "capacidadesIA", numero: "26", texto: "¿Para cuáles capacidades usa IA?", tipo: "multi", opciones: ["Textos", "Imágenes o video", "Traducir", "Chatbot", "Automatizar", "Pronósticos", "Voz", "Imágenes", "Recomendaciones", "Agentes autónomos", "Funciones integradas en software"], filtro: r => r.usaIA === "Sí" },
  { id: "accesoIA", numero: "27", texto: "¿Cómo accede a estas soluciones?", tipo: "multi", opciones: ["Versiones gratuitas", "Suscripciones empresariales", "Cuentas personales", "Incluidas en otros programas", "Proveedor", "Desarrolladas o adaptadas", "No sabe"], filtro: r => r.usaIA === "Sí" },
  { id: "procesosIA", numero: "28", texto: "¿En qué procesos utiliza hoy alguna herramienta de IA?", tipo: "matrix", filas: procesos, opciones: siNo, filtro: r => r.usaIA === "Sí" },
  { id: "actividadesIA", numero: "29", texto: "¿Para qué actividades concretas se utiliza?", tipo: "multi", opciones: ["Textos y correos", "Redes sociales", "Imágenes y videos", "Clientes", "Traducir", "Analizar documentos", "Analizar datos", "Cotizaciones", "Tareas repetitivas", "Pronósticos", "Diseñar", "Decisiones", "Programar", "Otra"], filtro: r => r.usaIA === "Sí" },
  { id: "otraActividadIA", numero: "29.1", texto: "Otra actividad, ¿cuál?", tipo: "text", filtro: r => r.usaIA === "Sí" && Array.isArray(r.actividadesIA) && r.actividadesIA.includes("Otra") },
  { id: "frecuenciaIA", numero: "30", texto: "¿Con qué frecuencia se utiliza la IA?", tipo: "select", opciones: ["Una o dos veces", "Ocasionalmente", "Varias veces al mes", "Varias veces a la semana", "Todos los días"], filtro: r => r.usaIA === "Sí" },
  { id: "automatica", numero: "31", texto: "¿Alguna herramienta funciona automáticamente?", tipo: "select", opciones: siNo, filtro: r => r.usaIA === "Sí" },
  { id: "personasIA", numero: "32", texto: "¿Cuántas personas de su equipo de trabajo utilizan IA para realizar tareas laborales?", tipo: "select", opciones: ["Ninguna", "1 persona", "De 2 a 3 personas", "De 4 a 10 personas", "De 11 a 25 personas", "De 26 a 50 personas", "Más de 50 personas", "No sabe"], filtro: r => r.usaIA === "Sí" },
  { id: "orientacionesIA", numero: "33", texto: "¿La empresa ha establecido orientaciones para el uso de IA?", tipo: "select", opciones: ["No existen", "Recomendaciones informales", "Procedimientos en diseño", "Políticas documentadas", "Controles sobre datos y resultados"], filtro: r => r.usaIA === "Sí" },
  { id: "beneficiosActuales", numero: "34", texto: "¿Qué beneficios ha obtenido o espera obtener mediante IA?", tipo: "matrix", filas: beneficios, opciones: ["Sí", "No", "Es pronto"], filtro: r => r.usaIA === "Sí" },
  { id: "beneficiosFuturos", numero: "35", texto: "¿Cuáles de estos beneficios esperaría obtener con inteligencia artificial en los próximos doce meses?", tipo: "matrix", filas: beneficios, opciones: siNo, filtro: r => r.usaIA === "Sí" },
  { id: "resultados", numero: "36", texto: "¿Cómo califica los resultados obtenidos?", tipo: "select", opciones: ["Muy bajos", "Bajos", "Moderados", "Buenos", "Muy buenos", "No se han medido", "No sabe"], filtro: r => r.usaIA === "Sí" },
  { id: "detalleResultados", numero: "36.1", texto: "Detalle los resultados obtenidos con el uso de la inteligencia artificial", tipo: "text", filtro: r => r.usaIA === "Sí" && r.resultados !== "No se han medido" },
  { id: "indicadores", numero: "37", texto: "¿La empresa mide el impacto del uso de IA mediante indicadores?", tipo: "select", opciones: ["No lo mide", "Apreciaciones", "Ocasionalmente", "Indicadores básicos", "Indicadores periódicos"], filtro: r => r.usaIA === "Sí" },
  { id: "limitaciones", numero: "38", texto: "Para cada situación, indique qué tanto limita hoy a su empresa para usar o ampliar el uso de inteligencia artificial", tipo: "matrix", filas: limitaciones, opciones: ["0 No limita", "1 Poco", "2 Bastante", "3 Principal", "NS" ] },
  { id: "otraLimitacion", numero: "38.1", texto: "Otra situación que limita el uso de inteligencia artificial, ¿cuál?", tipo: "text", filtro: r => Array.isArray(r.limitaciones) && r.limitaciones.some(item => item.startsWith("Otra:")) },
  { id: "utilidadIA", numero: "39", texto: "¿La inteligencia artificial es necesaria o útil para una empresa como la suya?", tipo: "select", opciones: ["Sí, claramente", "Tal vez", "No lo creo necesario", "No sabe"] },
  { id: "preocupaciones", numero: "40", texto: "¿Qué tanto le preocupan las siguientes situaciones relacionadas con el uso de inteligencia artificial (IA) en su empresa?", tipo: "matrix", filas: ["Información confidencial", "Datos personales", "Errores", "Dependencia", "Uso no autorizado", "Propiedad intelectual", "Puestos de trabajo", "Discriminación", "No tiene preocupaciones", "Otra"], opciones: ["0 Nada", "1 Poco", "2 Bastante", "3 Mucho", "NS"] },
  { id: "otraPreocupacion", numero: "40.1", texto: "Otra situación que le preocupa, ¿cuál?", tipo: "text", filtro: r => Array.isArray(r.preocupaciones) && r.preocupaciones.some(item => item.startsWith("Otra:")) },
  { id: "revisionIA", numero: "41", texto: "¿Con qué frecuencia se revisa la información producida por herramientas de IA antes de utilizarla?", tipo: "select", opciones: ["Nunca", "Algunas veces", "Generalmente", "Siempre"], filtro: r => r.usaIA === "Sí" },
  { id: "criteriosRevision", numero: "42", texto: "¿Existen criterios definidos para esa revisión?", tipo: "select", opciones: ["Sí, documentados", "Sí, informales", "No existen", "No sabe"], filtro: r => r.usaIA === "Sí" },
  { id: "procesosFuturos", numero: "43", texto: "¿Le gustaría implementar o fortalecer IA en estos procesos?", tipo: "matrix", filas: procesos, opciones: siNo },
  { id: "tresProcesos", numero: "44", texto: "De los procesos que marcó en la pregunta anterior, ¿cuáles son los tres más importantes para su empresa?", tipo: "multi", opciones: procesos },
  { id: "problema", numero: "45", texto: "¿En cuál proceso está el principal problema que quisiera resolver?", tipo: "text" },
  { id: "apoyo", numero: "46", texto: "¿Qué tipo de apoyo necesita la empresa?", tipo: "multi", opciones: ["Sensibilización", "Capacitación básica", "Herramientas específicas", "Casos de uso", "Datos", "Automatización", "Prototipo", "Privacidad y seguridad", "Políticas", "Acompañamiento individual", "Otro"] },
  { id: "otroApoyo", numero: "46.1", texto: "Otro tipo de apoyo, ¿cuál?", tipo: "text", filtro: r => Array.isArray(r.apoyo) && r.apoyo.includes("Otro") },
  { id: "modalidad", numero: "47", texto: "¿Qué modalidad de formación o acompañamiento prefiere?", tipo: "select", opciones: ["Presencial", "Virtual", "Híbrida", "En la empresa", "Combinación"] },
  { id: "participantes", numero: "48", texto: "¿Quiénes deberían participar en el proceso?", tipo: "multi", opciones: ["Propietarios y directivos", "Administrativos", "Comercial y mercadeo", "Operativos", "Tecnología", "Diferentes áreas", "Otro"] },
  { id: "otroParticipante", numero: "48.1", texto: "Otro participante, ¿quién?", tipo: "text", filtro: r => Array.isArray(r.participantes) && r.participantes.includes("Otro") },
  { id: "presupuestoAcompanamiento", numero: "49", texto: "¿Qué presupuesto prevé destinar su empresa en los próximos 12 meses para los apoyos en IA que indicó necesitar?", tipo: "select", opciones: ["No tiene previsto destinar recursos", "Aún no ha definido el presupuesto", "Menos de 2 millones", "De 2 a menos de 10 millones", "De 10 a menos de 30 millones", "30 millones o más", "No sabe", "Prefiere no responder"] },
  { id: "probabilidad", numero: "50", texto: "Probabilidad de participar en el proceso, de 0 (no participaría) a 10 (participaría)", tipo: "scale", opciones: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"] },
  { id: "horas", numero: "51", texto: "¿Cuántas horas a la semana podría dedicar la empresa al proceso de acompañamiento?", tipo: "number" },
  { id: "responsable", numero: "52", texto: "En caso de ser seleccionada, ¿la empresa podría designar una persona responsable del proceso?", tipo: "select", opciones: ["Sí", "Probablemente", "No", "No sabe"] },
  { id: "direccion", numero: "53", texto: "¿La dirección participaría en la definición y seguimiento?", tipo: "select", opciones: ["Sí", "Parcialmente", "No", "Aún no se ha consultado"] },
  { id: "informacionImplementacion", numero: "54", texto: "¿La empresa cuenta con información que pueda utilizarse para desarrollar un ejercicio de implementación?", tipo: "select", opciones: ["Organizada y disponible", "Sí, requiere organización", "Información limitada", "No cuenta", "No sabe"] },
  { id: "visita", numero: "55", texto: "¿Autoriza una visita o entrevista de profundización?", tipo: "select", opciones: ["Sí", "No", "Requiere información adicional"], filtro: r => r.autorizaContacto === "Sí, autorizo" },
  { id: "contactoNombre", numero: "56", texto: "Nombre de la persona responsable", tipo: "text", filtro: r => r.autorizaContacto === "Sí, autorizo" || r.autorizaProveedores === "Sí, autorizo" },
  { id: "contactoCargo", numero: "57", texto: "Cargo", tipo: "text", filtro: r => r.autorizaContacto === "Sí, autorizo" || r.autorizaProveedores === "Sí, autorizo" },
  { id: "contactoTelefono", numero: "58", texto: "Número de teléfono", tipo: "text", filtro: r => r.autorizaContacto === "Sí, autorizo" || r.autorizaProveedores === "Sí, autorizo" },
  { id: "contactoCorreo", numero: "59", texto: "Correo electrónico", tipo: "text", filtro: r => r.autorizaContacto === "Sí, autorizo" || r.autorizaProveedores === "Sí, autorizo" },
  { id: "comentario", numero: "60", texto: "¿Desea agregar algún comentario u observación?", tipo: "text" },
];

const autorizaciones: Pregunta[] = [
  { id: "autorizaContacto", numero: "0.2", texto: "Autorizo que el equipo organizador de EXPO IA me contacte por teléfono o correo para ampliar la información o invitarme a las actividades del evento.", tipo: "select", opciones: ["Sí, autorizo", "No autorizo"] },
  { id: "autorizaProveedores", numero: "0.3", texto: "Autorizo que el perfil de necesidad tecnológica de mi empresa sea compartido con proveedores preseleccionados para agendar reuniones en AI Business Match.", tipo: "select", opciones: ["Sí, autorizo", "No autorizo"] },
];

export default function CuestionarioEmpresas() {
  const [respuestas, setRespuestas] = useState<Record<string, string | string[]>>({});
  const [aceptaPolitica, setAceptaPolitica] = useState(false);
  const [inicio, setInicio] = useState(false);
  const [rechazado, setRechazado] = useState(false);
  const [paso, setPaso] = useState(0);
  const [modalAbierto, setModalAbierto] = useState(false);
  const [enviado, setEnviado] = useState(false);
  const [error, setError] = useState("");

  const visibles = useMemo(() => [...autorizaciones, ...preguntas].filter((pregunta) => !pregunta.filtro || pregunta.filtro(respuestas)), [respuestas]);
  const pregunta = visibles[paso];
  const progreso = visibles.length ? Math.round(((paso + 1) / visibles.length) * 100) : 0;

  function actualizar(id: string, valor: string | string[]) { setRespuestas((actual) => ({ ...actual, [id]: valor })); }
  function alternar(id: string, opcion: string) {
    const actual = Array.isArray(respuestas[id]) ? respuestas[id] as string[] : [];
    if (id === "tresProcesos" && !actual.includes(opcion) && actual.length >= 3) {
      setError("Selecciona máximo tres procesos.");
      return;
    }
    setError("");
    actualizar(id, actual.includes(opcion) ? actual.filter((item) => item !== opcion) : [...actual, opcion]);
  }
  function comenzar() {
    if (!aceptaPolitica || respuestas.autorizacionPrincipal !== "si") { setError("Debes leer la política y autorizar el tratamiento estadístico para acceder al cuestionario."); return; }
    setError(""); setInicio(true); setPaso(0);
  }
  function continuar() {
    const valor = respuestas[pregunta.id];
    const matrizIncompleta = pregunta.id === "recursos" && pregunta.filas?.some((fila) => !Array.isArray(valor) || !valor.some((respuesta) => respuesta.startsWith(`${fila}:`)));
    if (!valor || (Array.isArray(valor) && valor.length === 0) || matrizIncompleta) {
      setError(matrizIncompleta ? "Responde todas las filas para continuar." : "Selecciona o escribe una respuesta para continuar.");
      return;
    }
    setError("");
    if (paso < visibles.length - 1) { setPaso((actual) => actual + 1); return; }
    void enviar();
  }
  async function enviar() {
    if (!respuestas.empresa || !respuestas.usaIA) { setError("Completa los campos obligatorios antes de enviar."); return; }
    setError("");
    try {
      const respuesta = await fetch("/api/cuestionario-empresas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aceptaPolitica, respuestas }),
      });
      const resultado = await respuesta.json();
      if (!respuesta.ok) throw new Error(resultado.error || "No se pudo guardar el cuestionario.");
      setEnviado(true);
    } catch (errorDeEnvio) {
      setError(errorDeEnvio instanceof Error ? errorDeEnvio.message : "No se pudo guardar el cuestionario.");
    }
  }

  if (enviado) return <main className="min-h-screen bg-expoia-bg"><HeaderSimple /><section className="mx-auto max-w-2xl px-5 py-24 text-center"><p className="font-display text-sm tracking-[0.2em] text-expoia-cyan">RESPUESTA RECIBIDA</p><h1 className="mt-4 font-display text-4xl font-semibold text-expoia-navy">Gracias por fortalecer el futuro empresarial del Huila.</h1><p className="mt-5 text-expoia-gray-dark">Tus respuestas fueron registradas para el análisis agregado y las acciones de acompañamiento.</p></section></main>;
  if (rechazado) return <main className="min-h-screen bg-expoia-bg"><HeaderSimple /><section className="mx-auto max-w-2xl px-5 py-24 text-center"><p className="font-display text-sm tracking-[0.2em] text-expoia-cyan">PARTICIPACIÓN FINALIZADA</p><h1 className="mt-4 font-display text-4xl font-semibold text-expoia-navy">Gracias por tu tiempo.</h1><p className="mt-5 text-expoia-gray-dark">Al no autorizar el tratamiento estadístico, el cuestionario finaliza y tu respuesta queda registrada como rechazo informado.</p></section></main>;

  return <main className="min-h-screen bg-expoia-bg"><HeaderSimple /><section className="border-b border-expoia-border bg-expoia-navy"><div className="mx-auto max-w-5xl px-5 py-14 text-white sm:px-6 sm:py-20"><p className="font-display text-sm tracking-[0.2em] text-expoia-cyan">CÁMARA DE COMERCIO DEL HUILA · FET</p><h1 className="mt-4 max-w-3xl font-display text-4xl font-semibold md:text-5xl">Cuestionario de inteligencia artificial en las empresas del Huila</h1><p className="mt-5 max-w-2xl text-white/75">Una pregunta a la vez. Tus respuestas ayudan a identificar oportunidades reales de acompañamiento.</p></div></section>{!inicio ? <Consentimiento aceptaPolitica={aceptaPolitica} setAceptaPolitica={setAceptaPolitica} actualizar={actualizar} respuestas={respuestas} abrirPolitica={() => setModalAbierto(true)} comenzar={comenzar} rechazar={() => setRechazado(true)} error={error} /> : <form onSubmit={(event) => { event.preventDefault(); continuar(); }} className="mx-auto max-w-5xl px-5 py-10 sm:px-6 sm:py-16"><div className="mb-8 flex items-center justify-between"><div><p className="font-display text-xs font-semibold tracking-[0.2em] text-expoia-cyan">PREGUNTA {pregunta.numero}</p><p className="mt-1 text-sm text-expoia-gray-mid">{paso + 1} de {visibles.length}</p></div><div className="text-right"><span className="font-display text-3xl font-semibold text-expoia-navy">{progreso}%</span><p className="text-[10px] tracking-[0.18em] text-expoia-gray-mid">DEL RECORRIDO</p></div></div><div className="mb-8 h-1 bg-expoia-border"><div className="h-1 bg-gradient-to-r from-expoia-magenta to-expoia-cyan transition-all" style={{ width: `${progreso}%` }} /></div><div className="rounded-none border border-expoia-border bg-white p-6 shadow-sm sm:p-12"><Question pregunta={pregunta} valor={respuestas[pregunta.id]} actualizar={actualizar} alternar={alternar} /><div className="mt-9 flex items-center justify-between gap-4"><button type="button" onClick={() => setPaso((actual) => Math.max(0, actual - 1))} disabled={paso === 0} className="font-display text-sm font-semibold text-expoia-navy disabled:invisible">← Anterior</button><button type="submit" className="bg-gradient-to-r from-expoia-magenta to-[#9fbcff] px-7 py-4 font-display text-sm font-semibold text-white">{paso === visibles.length - 1 ? "Enviar cuestionario ↗" : "Continuar ↗"}</button></div></div>{error && <p className="mt-5 text-sm font-medium text-expoia-magenta">{error}</p>}</form>}<PoliticaModal abierto={modalAbierto} onCerrar={() => setModalAbierto(false)} /></main>;
}

function HeaderSimple() { return <header className="border-b border-expoia-border bg-expoia-bg"><div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3 sm:px-6"><Link href="/" aria-label="Volver a EXPOIA 2026"><Image src="/logo-expoia.png" alt="EXPOIA 2026" width={200} height={68} className="h-10 w-auto" priority /></Link><Link href="/" className="text-sm font-medium text-expoia-navy hover:text-expoia-cyan">Volver a EXPOIA</Link></div></header>; }
function Consentimiento({ aceptaPolitica, setAceptaPolitica, actualizar, respuestas, abrirPolitica, comenzar, rechazar, error }: { aceptaPolitica: boolean; setAceptaPolitica: (valor: boolean) => void; actualizar: (id: string, valor: string | string[]) => void; respuestas: Record<string, string | string[]>; abrirPolitica: () => void; comenzar: () => void; rechazar: () => void; error: string }) {
  return <section className="mx-auto max-w-3xl px-5 py-10 sm:px-6 sm:py-16"><div className="border border-expoia-border bg-white p-6 shadow-sm sm:p-10"><p className="font-display text-xs font-semibold tracking-[0.2em] text-expoia-cyan">PASO 0 · ANTES DE EMPEZAR</p><h2 className="mt-3 font-display text-3xl font-semibold text-expoia-navy">Aviso de privacidad y autorización</h2><p className="mt-4 text-sm leading-7 text-expoia-gray-dark">La participación es voluntaria. La información será utilizada de manera agregada para conocer la adopción de inteligencia artificial en las empresas del Huila y estructurar acciones de formación y acompañamiento.</p><button type="button" onClick={abrirPolitica} className="mt-5 font-display text-sm font-semibold text-expoia-navy underline decoration-expoia-cyan decoration-2 underline-offset-4">Leer política de tratamiento completa ↗</button><div className="mt-7 border-t border-expoia-border pt-6"><p className="font-display text-base font-semibold text-expoia-navy">0.1. He leído el aviso anterior y autorizo el tratamiento de la información suministrada, con fines estadísticos agregados.</p><p className="mt-2 text-sm italic text-expoia-magenta">Si eliges “No autorizo”, el cuestionario finaliza y se registra como rechazo informado.</p><div className="mt-5 grid gap-3 sm:grid-cols-2"><label className={`flex cursor-pointer items-center gap-3 border p-4 text-sm ${respuestas.autorizacionPrincipal === "si" ? "border-expoia-cyan bg-expoia-cyan/5" : "border-expoia-border"}`}><input type="radio" name="autorizacionPrincipal" checked={respuestas.autorizacionPrincipal === "si"} onChange={() => actualizar("autorizacionPrincipal", "si")} className="h-4 w-4 accent-expoia-cyan" />Sí, autorizo y deseo continuar.</label><label className={`flex cursor-pointer items-center gap-3 border p-4 text-sm ${respuestas.autorizacionPrincipal === "no" ? "border-expoia-magenta bg-expoia-magenta/5" : "border-expoia-border"}`}><input type="radio" name="autorizacionPrincipal" checked={respuestas.autorizacionPrincipal === "no"} onChange={() => { actualizar("autorizacionPrincipal", "no"); rechazar(); }} className="h-4 w-4 accent-expoia-magenta" />No autorizo.</label></div></div><label className="mt-6 flex items-start gap-3 text-sm text-expoia-navy"><input type="checkbox" checked={aceptaPolitica} onChange={(event) => setAceptaPolitica(event.target.checked)} className="mt-1 h-4 w-4 accent-expoia-cyan" />Confirmo que leí la política de tratamiento y el aviso de privacidad. *</label>{error && <p className="mt-5 text-sm font-medium text-expoia-magenta">{error}</p>}<button type="button" onClick={comenzar} className="mt-7 w-full bg-gradient-to-r from-expoia-magenta to-[#9fbcff] px-7 py-4 font-display text-sm font-semibold text-white sm:w-auto">Continuar al cuestionario ↗</button></div></section>;
}
function Question({ pregunta, valor, actualizar, alternar }: { pregunta: Pregunta; valor?: string | string[]; actualizar: (id: string, valor: string | string[]) => void; alternar: (id: string, opcion: string) => void }) {
  const seleccionado = typeof valor === "string" ? valor : "";
  const valoresMatriz = Array.isArray(valor) ? valor : [];
  return <fieldset className="rounded-2xl border border-expoia-border bg-white p-5 sm:p-6"><legend className="max-w-3xl font-display text-base font-semibold text-expoia-navy"><span className="mr-2 text-expoia-cyan">{pregunta.numero}.</span>{pregunta.texto}</legend>{pregunta.tipo === "text" || pregunta.tipo === "number" ? <input type={pregunta.tipo} value={seleccionado} onChange={(event) => actualizar(pregunta.id, event.target.value)} className="mt-4 w-full rounded-lg border border-expoia-border px-4 py-3 text-expoia-navy outline-none focus:border-expoia-cyan" placeholder="Escribe tu respuesta" /> : pregunta.tipo === "matrix" ? <div className="mt-4 overflow-x-auto"><div className="min-w-[620px]"><div className="grid grid-cols-[minmax(240px,1fr)_repeat(5,minmax(72px,auto))] gap-2 border-b border-expoia-border pb-2 text-center text-xs font-semibold text-expoia-gray-mid"><span className="text-left">Situación</span>{pregunta.opciones?.map((opcion) => <span key={opcion}>{opcion}</span>)}</div>{pregunta.filas?.map((fila) => <div key={fila} className="grid grid-cols-[minmax(240px,1fr)_repeat(5,minmax(72px,auto))] items-center gap-2 border-b border-expoia-border/60 py-3 text-sm text-expoia-gray-dark"><span>{fila}</span>{pregunta.opciones?.map((opcion) => <label key={opcion} className="flex justify-center"><input type="radio" name={`${pregunta.id}-${fila}`} value={opcion} checked={valoresMatriz.includes(`${fila}: ${opcion}`)} onChange={() => actualizar(pregunta.id, [...valoresMatriz.filter((item) => !item.startsWith(`${fila}:`)), `${fila}: ${opcion}`])} className="h-4 w-4 accent-expoia-cyan" /></label>)}</div>)}</div></div> : pregunta.tipo === "multi" ? <div className="mt-4 grid gap-2 sm:grid-cols-2">{pregunta.opciones?.map((opcion) => <label key={opcion} className="flex items-start gap-2 text-sm text-expoia-gray-dark"><input type="checkbox" checked={Array.isArray(valor) && valor.includes(opcion)} onChange={() => alternar(pregunta.id, opcion)} className="mt-0.5 h-4 w-4 rounded accent-expoia-cyan" />{opcion}</label>)}</div> : pregunta.tipo === "scale" ? <div className="mt-4 flex flex-wrap gap-2">{pregunta.opciones?.map((opcion) => <button type="button" key={opcion} onClick={() => actualizar(pregunta.id, opcion)} className={`h-10 w-10 rounded-full border text-sm font-semibold ${seleccionado === opcion ? "border-expoia-magenta bg-expoia-magenta text-white" : "border-expoia-border text-expoia-navy"}`}>{opcion}</button>)}</div> : <div className="mt-4 grid gap-2 sm:grid-cols-2">{pregunta.opciones?.map((opcion) => <label key={opcion} className="flex items-start gap-2 text-sm text-expoia-gray-dark"><input type="radio" name={pregunta.id} value={opcion} checked={seleccionado === opcion} onChange={() => actualizar(pregunta.id, opcion)} className="mt-0.5 h-4 w-4 accent-expoia-cyan" />{opcion}</label>)}</div>}</fieldset>;
}
